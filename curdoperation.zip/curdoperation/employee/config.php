<?php
$con = new mysqli ("localhost","root","","phpcrud");

if($con){
    die(mysqli_error($con));
}

?>